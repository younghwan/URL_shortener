module.exports = {
    host     : 'localhost',
    user     : 'root',
    password : '!as3426845',
    database : 'my_db'
  };