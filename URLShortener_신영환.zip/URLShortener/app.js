/* app.js */
const express = require('express');
const app = express();
const ejs = require("ejs");
const bodyParser = require('body-parser');
const utils = require('./utils');
const mysql = require('mysql');
const dbconfig = require('./config/database.js');
const { urlencoded, request } = require('express');
const connection = mysql.createConnection(dbconfig)
connection.connect();

app.set("view engine","ejs");
app.use(express.static(__dirname+'/'));
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json());

app.get("/",function(req,res){
    res.render("home",{});
})

app.get("/re/:url",function(req,res){

    const sql = 'SELECT * FROM url WHERE shorten_url = ?';
    var params =  '/re/'+req.params.url
    
    var origin_url = ''
    connection.query(sql,params, function(error, rows, fields) {
        if (error) throw error
    
        origin_url = rows[0]['origin_url'];
     
        res.redirect(origin_url)
      });
})


app.post("/check",function(req,res){
    
    var params =  req.body['input']

    if(!utils.checkUrlForm(params)){
        res.send('잘못된 URL입니다.')
        return
    }

    const sql = 'SELECT shorten_url FROM url WHERE origin_url = ?';

    connection.query(sql,params, function(error, rows, fields) {
        if (error){
            console.log("query error : "+error)
        }

        if(rows[0] == null){
            var result = '/re/'+utils.base62_encode(2390687438976,req.body['input']);

            var sql = 'INSERT INTO url (origin_url,shorten_url) VALUES(?,?)';
            var params = [req.body['input'],result]

            connection.query(sql,params,function(err,rows,fields) {
                if(err){
                    console.log("query error : "+err)
                }else{
                    console.log(rows.insertId)
                }
            })
            res.send(result);
        }else{
            res.send(rows[0]['shorten_url']);
        }
      });
})

app.listen(3000,function(){
    console.log("running");
})